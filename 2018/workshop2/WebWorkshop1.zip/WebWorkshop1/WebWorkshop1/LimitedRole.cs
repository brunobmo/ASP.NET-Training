namespace WebWorkshop1
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using Models;

    public partial class LimitedRole : DbContext
    {
        public LimitedRole()
            : base("name=LimitedRole")
        {
        }

        public virtual DbSet<Atleta> Atleta { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Atleta>()
                .Property(e => e.nome)
                .IsUnicode(false);

            modelBuilder.Entity<Atleta>()
                .Property(e => e.genero)
                .IsFixedLength()
                .IsUnicode(false);
        }
    }
}
