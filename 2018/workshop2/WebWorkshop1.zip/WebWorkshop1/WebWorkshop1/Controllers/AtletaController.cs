﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebWorkshop1.Models;

namespace WebWorkshop1.Controllers
{
    public class AtletaController : Controller
    {
        LimitedRole db = new LimitedRole();
        public ActionResult Index()
        {
            return View();
        }

        public string Welcome()
        {
            return "This is the Welcome action method...";
        }

        [HttpPost]
        public ActionResult AdicionarAtleta([Bind(Include = "nome,data_nascimento,genero, username, password")] Atleta atleta)
        {
            if (ModelState.IsValid)
            {
                atleta.password = MyHelpers.HashPassword(atleta.password);
                db.Atleta.Add(atleta);
                db.SaveChanges();
            }
            return RedirectToAction("sucessOperation");
        }

        public ActionResult sucessOperation()
        {
            ViewBag.title = "Atleta adicionado com sucesso";
            ViewBag.mensagem = "Atleta inserido com sucesso";
            return View("_sucessView");
        }

        public ActionResult verAtletas()
        {
            var atletas = (from m in db.Atleta
                           select m); 
            return View(atletas);
        }
    }
}