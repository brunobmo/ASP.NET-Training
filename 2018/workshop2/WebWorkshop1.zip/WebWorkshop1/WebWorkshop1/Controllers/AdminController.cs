﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebWorkshop1.Models;

namespace WebWorkshop1.Controllers
{
    [Authorize(Roles = "admin")]
    public class AdminController : Controller
    {
        RoleContext db = new RoleContext();
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AdicionarAtleta([Bind(Include = "nome,data_nascimento,genero, username, password")] Atleta atleta)
        {
            if (ModelState.IsValid)
            {
                atleta.password = MyHelpers.HashPassword(atleta.password);
                db.Atleta.Add(atleta);
                db.SaveChanges();
            }
            return RedirectToAction("sucessOperation");
        }

        public ActionResult sucessOperation()
        {
            ViewBag.title = "Atleta adicionado com sucesso";
            ViewBag.mensagem = "Atleta inserido com sucesso";
            return View();
        }

    }
}