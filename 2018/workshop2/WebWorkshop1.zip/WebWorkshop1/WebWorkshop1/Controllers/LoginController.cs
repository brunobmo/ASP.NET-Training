﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using WebWorkshop1.Models;

namespace WebWorkshop1.Controllers
{
    public class LoginController : Controller
    {

        EquipaContext db = new EquipaContext();

        public ActionResult Index()
        {
            return View();
        }
        
        public ActionResult loginSucess()
        {
            return RedirectToAction("Index", "Login");
        }

        [HttpPost]
        public ActionResult Login(string username, string password)
        {
            if (ModelState.IsValid)
            {
                var atletas = (from m in db.Atleta
                               where m.username == username
                               select m);
                if (atletas.ToList<Atleta>().Count > 0)
                {
                    Atleta atleta = atletas.ToList<Atleta>().ElementAt<Atleta>(0);
                    using (MD5 md5Hash = MD5.Create())
                    {
                       if (MyHelpers.VerifyMd5Hash(md5Hash, password, atleta.password))
                        {
                            HttpCookie cookie = MyHelpers.CreateAuthorizeTicket(atleta.id_atleta.ToString(), atleta.role);
                            Response.Cookies.Add(cookie);

                        }
                        else
                        {
                            ModelState.AddModelError("password", "Password incorreta!");
                            return View("Index");
                        }
                    }

                }
                else
                {
                    ModelState.AddModelError("", "Login data is incorrect!");
                    return View("Index");

                }
            }
            else
            {
                ModelState.AddModelError("", "Invalid Request");
                return View("Index");

            }
            return RedirectToAction("loginSucess", "Login");
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Login");
        }

    }
}